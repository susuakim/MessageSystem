package com.smhrd.model;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.smhrd.db.SqlSessionManager;

public class BoardDAO {

	private SqlSessionFactory sqlsessionFactory = SqlSessionManager.getSqlSession();

	// 게시글 작성
	// insert하면 int 타입으로 반환된다
	public int insertBoard(BoardDTO dto) {
		SqlSession session = sqlsessionFactory.openSession(true);
		int row = session.insert("insertBoard", dto);
		session.close();

		return row;
	}

	// 전체 게시글 조회
	public ArrayList<BoardDTO> showBoard() {
		SqlSession session = sqlsessionFactory.openSession(true);
		ArrayList<BoardDTO> board_list = (ArrayList) session.selectList("showBoard");
		session.close();

		return board_list;
	}
	
	// 세부 게시글 조회
	public BoardDTO detailBoard(int num) {
		SqlSession session = sqlsessionFactory.openSession(true);
		BoardDTO board = session.selectOne("detailBoard", num);
		session.close();
		
		return board;
		
	}
}
