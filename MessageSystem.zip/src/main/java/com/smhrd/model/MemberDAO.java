package com.smhrd.model;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.smhrd.db.SqlSessionManager;

public class MemberDAO {
	
	private SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSqlSession();
	
	// 회원가입 기능
	public int join(MemberDTO dto) {
		// true -> auto commit
		SqlSession session = sqlSessionFactory.openSession(true);
		int row = session.insert("join", dto);
		session.close();
		
		return row;
	}
	
	// 로그인 기능
	public MemberDTO login(MemberDTO dto) {
		SqlSession session = sqlSessionFactory.openSession(true);
		MemberDTO info = session.selectOne("login", dto);
		session.close();
		
		return info;
	}
	
	// 업데이트 기능
	public int update(MemberDTO dto) {
		SqlSession session = sqlSessionFactory.openSession(true);
		int row = session.update("update", dto);
		session.close();
		
		return row;
	}
	
	// 회원정보조회 기능
	public ArrayList<MemberDTO> showMember() {
		SqlSession session = sqlSessionFactory.openSession(true);
		ArrayList<MemberDTO> mem_list = (ArrayList)session.selectList("showMember");
		session.close();
		
		return mem_list;
	}
	
	// 데이터 삭제 기능
	public int deleteMember(String email) {
		SqlSession session = sqlSessionFactory.openSession(true);
		int row = session.delete("deleteMember", email);
		session.close();
		
		return row;
	}

}
