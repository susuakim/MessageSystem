package com.smhrd.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smhrd.model.MemberDAO;
import com.smhrd.model.MemberDTO;

public class UpdateService extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
System.out.println("[UpdateService]");
		
		// 1. post 방식 디코딩
		request.setCharacterEncoding("UTF-8");
		
		// 2. 데이터 받아오기
		String pw = request.getParameter("pw");
		String tel = request.getParameter("tel");
		String address = request.getParameter("address");
		String email = request.getParameter("email");
		
		System.out.println("repw: " + pw);
		System.out.println("retel: " + tel);
		System.out.println("readdress: " + address);
		
		// Case01) 세션으로 email 정보 가져오기
		//HttpSession session = request.getSession();
		//MemberDTO info = (MemberDTO)session.getAttribute("info");
		//String email = info.getEmail();
		
		// Case02) hidden으로 email 정보 가져오기
		
		// 3. MemberDTO로 묶기
		MemberDTO dto = new MemberDTO(email, pw, tel, address);
		
		// 4. update 메소드 호출
		int row = new MemberDAO().update(dto);
		
		// 5. 실행결과 확인
		if(row == 1) {
			System.out.println("회원정보수정 성공");
			
			// session에 있는 info 정보도 업데이트하기
			HttpSession session = request.getSession();
			session.setAttribute("info", dto);
			
		}else {
			System.out.println("회원정보수정 실패");
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("./Main.jsp");
		rd.forward(request, response);
	}
}
