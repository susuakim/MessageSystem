package com.smhrd.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.smhrd.model.MemberDAO;

public class DeleteMemberService extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("[DeleteMemberService]");
		
		// 데이터 받아오기
		String email = request.getParameter("email");
		
		// deleteMamber 메소드 호출
		int row = new MemberDAO().deleteMember(email);
		
		if(row == 1) {
			System.out.println("회원정보삭제 성공");
		}else {
			System.out.println("회원정보삭제 실패");
		}
		
		RequestDispatcher rd =request.getRequestDispatcher("./ShowMember.jsp");
		rd.forward(request, response);	}

}
