package com.smhrd.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.smhrd.model.MemberDAO;
import com.smhrd.model.MessageDAO;
import com.smhrd.model.MessageDTO;

public class MessageService extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("[MessageService]");
		
		// 1. post방식 디코딩
		request.setCharacterEncoding("UTF-8");
		
		// 2. 데이터 받아오기
		String sender = request.getParameter("sender");
		String recipient = request.getParameter("recipient");
		String message = request.getParameter("message");
		
		System.out.println("sender: " + sender);
		System.out.println("recipient: " + recipient);
		System.out.println("message: " + message);
		
		// 3. MessageDTO로 묶기
		MessageDTO dto = new MessageDTO(sender, recipient, message);
		
		// 4. insertMessage 메소드 호출
		int row = new MessageDAO().insertMessage(dto);
		
		// 5. 실행결과 확인
		if(row > 0) {
			System.out.println("메시지 전송 성공");
		}else {
			System.out.println("메시지 전송 실패");
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("./Main.jsp");
		rd.forward(request, response);
		
	}

}
