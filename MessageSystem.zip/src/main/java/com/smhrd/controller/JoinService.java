package com.smhrd.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.smhrd.model.MemberDAO;
import com.smhrd.model.MemberDTO;

public class JoinService extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("[JoinService]");
		
		// 1. post방식 디코딩
		request.setCharacterEncoding("UTF-8");
		
		// 2. 데이터 받아오기
		String email = request.getParameter("email");
		String pw = request.getParameter("pw");
		String tel = request.getParameter("tel");
		String address = request.getParameter("address");
		
		System.out.println("email: " + email);
		System.out.println("pw: " + pw);
		System.out.println("tel: " + tel);
		System.out.println("address: " + address);
		
		// 3. DTO로 묶기
		MemberDTO dto = new MemberDTO(email, pw, tel, address);
		
		// 4. join 메소드 호출
		int row = new MemberDAO().join(dto);
		
		// 5. 실행 결과 확인하기
		String moveURL = null;
		if(row==1) {
			System.out.println("회원가입 성공");
			// 성공시 JoinSuccess.jsp 으로 이동
			// 회원가입한 email 전송(request객체 활용)
			request.setAttribute("email", email);
			moveURL = "./JoinSuccess.jsp";
			
		}else {
			System.out.println("회원가입 실패");
			// 실패시 Main.jsp
			moveURL = "./Main.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher(moveURL);
		rd.forward(request, response);
		
	}

}
