package com.smhrd.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smhrd.model.MemberDAO;
import com.smhrd.model.MemberDTO;

public class LoginService extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("[LoginService]");
		
		// 1. post 방식 디코딩
		request.setCharacterEncoding("UTF-8");
		
		// 2. 데이터 받아오기
		String email = request.getParameter("email");
		String pw = request.getParameter("pw");
		
		System.out.println("email: " + email);
		System.out.println("pw: " + pw);
		
		// 3. DTO로 묶기
		MemberDTO dto = new MemberDTO(email, pw);
		
		// 4. login 메소드 호출
		MemberDTO info = new MemberDAO().login(dto);
		
		// 5. 실행결과 확인
		if(info != null) {
			System.out.println("로그인 성공");
			
			// 로그인한 정보 유지 -> session 사용
			HttpSession session = request.getSession();
			session.setAttribute("info", info);
			
		}else {
			System.out.println("로그인 실패");
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("./Main.jsp");
		rd.forward(request, response);
	}
}
