package com.smhrd.controller;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.smhrd.model.BoardDAO;
import com.smhrd.model.BoardDTO;

public class BoardService extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("[BoardService]");
		
		// 1. post 방식 인코딩 
		request.setCharacterEncoding("UTF-8");
		
		// 2. 파일업로드를 위한 변수 설정
		// 1) request 객체
		// 2) 파일을 저장할 경로
		String path = request.getServletContext().getRealPath("file");
		System.out.println(path);
		
		// 3) 파일의 최대크기 지정
		int maxSize = 10*1024*1024;
		
		// 4) 인코딩방식
		String encoding = "UTF-8";
		
		// 5) 중복제거
		DefaultFileRenamePolicy rename = new DefaultFileRenamePolicy();
		
		MultipartRequest multi = new MultipartRequest(request, path, maxSize, encoding, rename);
		
		// 3. 데이터 받아오기
		String title = multi.getParameter("title");
		String writer = multi.getParameter("writer");
		// 파일을 불러올 때 한글은 인코딩
		String filename = URLEncoder.encode(multi.getFilesystemName("filename"), "UTF-8"); // 중복된 파일 이름이 있으면,,
		String content = multi.getParameter("content");
		
		System.out.println("title: " + title);
		System.out.println("writer: " + writer);
		System.out.println("filename: " + filename);
		System.out.println("content: " + content);
		
		// 4. DTO로 묶기
		BoardDTO dto = new BoardDTO(title, writer, filename, content);
		
		// 5. insertBoard 메소드 호출
		int row = new BoardDAO().insertBoard(dto);
		
		if(row == 1) {
			System.out.println("파일 업로드 성공");
		}else {
			System.out.println("파일 업로드 실패");
		}
		
		RequestDispatcher rd = request.getRequestDispatcher("./BoardMain.jsp");
		rd.forward(request, response);
	}

}
