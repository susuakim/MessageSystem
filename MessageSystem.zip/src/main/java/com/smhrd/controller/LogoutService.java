package com.smhrd.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutService extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.print("[LogoutService]");
		
		// 로그아웃 = 로그인한 유저의 정보를 유지X
		// ->로그인 정보가 들어 있는 session을 삭제
		HttpSession session = request.getSession();
		
		// 세선 자체를 종료시키기
		// session.invalidate();
		session.removeAttribute("info");
				
		RequestDispatcher rd = request.getRequestDispatcher("./Main.jsp");
		rd.forward(request, response);
	}

}
